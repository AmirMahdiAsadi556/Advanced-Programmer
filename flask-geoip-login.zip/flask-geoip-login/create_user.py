# create_user.py
import json
from getpass import getpass
from werkzeug.security import generate_password_hash


PATH = "users.json"


def main():
username = input("username: ").strip()
pw = getpass("password: ")
if not username or not pw:
print("username/password required")
return
try:
with open(PATH, "r", encoding="utf-8") as f:
data = json.load(f)
except FileNotFoundError:
data = {}
data[username] = {"password_hash": generate_password_hash(pw)}
with open(PATH, "w", encoding="utf-8") as f:
json.dump(data, f, indent=2)
print(f"created user {username}")


if __name__ == '__main__':
main()