from flask import Flask, request, render_template, redirect, url_for, flash, session, jsonify
from werkzeug.security import check_password_hash
import json, os, requests, ipaddress
from dotenv import load_dotenv

load_dotenv()

SECRET_KEY = os.getenv("SECRET_KEY", "dev_secret")
GEO_MODE = os.getenv("GEO_MODE", "ipinfo").lower()       # ipinfo | maxmind
IPINFO_TOKEN = os.getenv("IPINFO_TOKEN", "")
MAXMIND_DB_PATH = os.getenv("MAXMIND_DB_PATH", "./data/GeoLite2-Country.mmdb")
USERS_PATH = os.getenv("USERS_PATH", "./users.json")
FORCE_PUBLIC_IP = os.getenv("FORCE_PUBLIC_IP", "1")       # "1": همیشه آی‌پی عمومی را بگیر

app = Flask(__name__)
app.secret_key = SECRET_KEY

# MaxMind (اختیاری)
try:
    import geoip2.database
except Exception:
    geoip2 = None

# ---------------- helpers ----------------
def load_users():
    try:
        with open(USERS_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def is_private_ip(ip_str):
    try:
        ip = ipaddress.ip_address(ip_str)
        return ip.is_private or ip.is_loopback
    except Exception:
        return False

def fetch_public_ip(timeout=3):
    """بازگرداندن آی‌پی عمومی با چند تأمین‌کننده به ترتیب اولویت."""
    # 1) ipify
    try:
        r = requests.get("", timeout=timeout)
        if r.status_code == 200:
            ip = r.json().get("ip")
            if ip:
                return ip, "ipify"
    except Exception:
        pass
    # 2) ifconfig.me
    try:
        r = requests.get("https://ifconfig.me/all.json", timeout=timeout, headers={"User-Agent":"curl/8"})
        if r.status_code == 200:
            ip = r.json().get("ip_addr")
            if ip:
                return ip, "ifconfig"
    except Exception:
        pass
    # 3) AWS checkip
    try:
        r = requests.get("", timeout=timeout)
        if r.status_code == 200:
            ip = r.text.strip()
            if ip:
                return ip, "aws-checkip"
    except Exception:
        pass
    return None, None

def get_client_ip_detailed():
    """همه‌ی منابع ممکن برای آی‌پی را جمع می‌کند و انتخاب نهایی را برمی‌گرداند."""
    # از هدرها
    headers_ip = None
    xff = request.headers.get("X-Forwarded-For", "")
    if xff:
        headers_ip = xff.split(",")[0].strip()
    # remote_addr
    remote_ip = request.remote_addr or "0.0.0.0"
    # public ip (سیستمی)
    public_ip, public_src = fetch_public_ip()

    # انتخاب
    reason = []
    chosen = None

    if FORCE_PUBLIC_IP == "1" and public_ip:
        chosen = public_ip
        reason.append(f"forced_public_ip({public_src})")
    else:
        # اگر هدر معتبر و خصوصی نبود، همان را
        if headers_ip and not is_private_ip(headers_ip):
            chosen = headers_ip
            reason.append("header_xff")
        elif not is_private_ip(remote_ip):
            chosen = remote_ip
            reason.append("remote_addr_public")
        elif public_ip:
            chosen = public_ip
            reason.append(f"fallback_public({public_src})")
        else:
            chosen = remote_ip
            reason.append("fallback_remote")

    return {
        "chosen_ip": chosen,
        "reason": "+".join(reason),
        "headers_ip": headers_ip,
        "remote_ip": remote_ip,
        "public_ip": public_ip,
        "public_src": public_src
    }

def ip_to_country(ip):
    if GEO_MODE == "maxmind" and geoip2:
        try:
            reader = geoip2.database.Reader(MAXMIND_DB_PATH)
            r = reader.country(ip)
            name = r.country.names.get("en") if r and r.country else None
            reader.close()
            return name or "Unknown"
        except Exception:
            return "Unknown"
    else:
        try:
            url = f"https://ipinfo.io/{ip}/json"
            params = {}
            if IPINFO_TOKEN:
                params["token"] = IPINFO_TOKEN
            r = requests.get(url, params=params, timeout=3)
            if r.status_code == 200:
                data = r.json()
                # ipinfo معمولا کد ISO می‌دهد (IR/US/DE/...)
                return data.get("country") or data.get("org") or "Unknown"
        except Exception:
            pass
        return "Unknown"

# ---------------- routes ----------------
@app.route("/", methods=["GET"])
def index():
    info = get_client_ip_detailed()
    ip = info["chosen_ip"]
    country = ip_to_country(ip)
    # لاگ تشخیصی در کنسول
    print(f"[IP DEBUG] chosen={ip} country={country} reason={info['reason']} "
          f"remote={info['remote_ip']} xff={info['headers_ip']} public={info['public_ip']}:{info['public_src']}")
    return render_template("index.html", ip=ip, country=country)

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        info = get_client_ip_detailed()
        ip = info["chosen_ip"]
        country = ip_to_country(ip)
        print(f"[IP DEBUG] /login chosen={ip} country={country} reason={info['reason']}")
        return render_template("login.html", ip=ip, country=country)

    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")
    users = load_users()
    user = users.get(username)

    if user and check_password_hash(user.get("password_hash", ""), password):
        session["username"] = username
        flash("ورود موفق ✅")
        return redirect(url_for("index"))
    else:
        flash("نام کاربری یا رمز عبور اشتباه است ❌")
        return redirect(url_for("login"))

@app.route("/debug")
def debug():
    """صفحه‌ی تشخیصی: تمام اطلاعات آی‌پی و کشور را به‌صورت JSON نشان می‌دهد."""
    info = get_client_ip_detailed()
    ip = info["chosen_ip"]
    country = ip_to_country(ip)
    info["country"] = country
    info["geo_mode"] = GEO_MODE
    return jsonify(info)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
