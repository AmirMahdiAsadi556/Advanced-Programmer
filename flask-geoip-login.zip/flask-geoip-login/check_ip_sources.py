import requests

def check_source(url, key=None):
    try:
        r = requests.get(url, timeout=5, headers={"User-Agent": "curl/8"})
        if r.status_code == 200:
            if key:
                return r.json().get(key)
            else:
                return r.text.strip()
    except Exception as e:
        return f"Error: {e}"
    return None

sources = {
    "ipify": ("https://api.ipify.org?format=json", "ip"),
    "ifconfig.me": ("https://ifconfig.me/all.json", "ip_addr"),
    "aws-checkip": ("https://checkip.amazonaws.com/", None),
}

print("🌐 Checking public IP from multiple sources...\n")
for name, (url, key) in sources.items():
    ip = check_source(url, key)
    print(f"{name:12s}: {ip}")
